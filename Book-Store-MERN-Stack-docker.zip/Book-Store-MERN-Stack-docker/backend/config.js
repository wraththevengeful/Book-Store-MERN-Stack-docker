export const PORT = 5555;

export const mongoDBURL =
  'mongodb://mongo:27017/my-library';
